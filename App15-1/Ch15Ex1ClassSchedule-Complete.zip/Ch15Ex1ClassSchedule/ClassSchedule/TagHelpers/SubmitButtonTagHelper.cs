using Microsoft.AspNetCore.Razor.TagHelpers;

namespace ClassSchedule.TagHelpers
{
    [HtmlTargetElement("button", Attributes = "button-type")]
    public class SubmitButtonTagHelper : TagHelper
    {
        [HtmlAttributeName("button-type")]
        public string ButtonType { get; set; } = "primary";

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            string css = ButtonType == "danger" ? "btn btn-danger" : "btn btn-primary";
            output.Attributes.SetAttribute("class", css);
            output.Attributes.RemoveAll("button-type");
        }
    }
}
