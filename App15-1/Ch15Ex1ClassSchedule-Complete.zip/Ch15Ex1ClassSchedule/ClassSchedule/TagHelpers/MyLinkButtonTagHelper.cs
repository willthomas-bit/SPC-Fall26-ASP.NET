using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace ClassSchedule.TagHelpers
{
    [HtmlTargetElement("my-link-button")]
    public class MyLinkButtonTagHelper : TagHelper
    {
        private IUrlHelperFactory urlHelperFactory;

        public MyLinkButtonTagHelper(IUrlHelperFactory helperFactory)
        {
            urlHelperFactory = helperFactory;
        }

        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewContext { get; set; } = null!;

        public string Action { get; set; } = "Index";
        public string Controller { get; set; } = string.Empty;
        public string Id { get; set; } = string.Empty;

        [HtmlAttributeName("class")]
        public string CssClass { get; set; } = "btn btn-outline-primary";

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            string controller = string.IsNullOrEmpty(Controller)
                ? ViewContext.RouteData.Values["controller"]?.ToString() ?? ""
                : Controller;

            var urlHelper = urlHelperFactory.GetUrlHelper(ViewContext);
            object? route = string.IsNullOrEmpty(Id) ? null : new { id = Id };
            string url = urlHelper.Action(Action, controller, route) ?? "";

            output.TagName = "a";
            output.Attributes.SetAttribute("href", url);
            output.Attributes.SetAttribute("class", CssClass);
        }
    }
}
