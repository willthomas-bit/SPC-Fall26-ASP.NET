using Microsoft.AspNetCore.Mvc;
using ClassSchedule.Models;

namespace ClassSchedule.ViewComponents
{
    public class DayFilterViewComponent : ViewComponent
    {
        private Repository<Day> days;

        public DayFilterViewComponent(ClassScheduleContext ctx)
        {
            days = new Repository<Day>(ctx);
        }

        public IViewComponentResult Invoke()
        {
            var options = new QueryOptions<Day> {
                OrderBy = d => d.DayId
            };
            return View(days.List(options));
        }
    }
}
