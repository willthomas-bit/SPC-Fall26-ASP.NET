using ClassSchedule.Controllers;
using ClassSchedule.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace ClassSchedule.Tests
{
    public class TeacherControllerTests
    {
        [Fact]
        public void Index_ReturnsViewWithTeachers()
        {
            var teachers = new List<Teacher>
            {
                new Teacher { TeacherId = 1, FirstName = "Ada", LastName = "Lovelace" },
                new Teacher { TeacherId = 2, FirstName = "Alan", LastName = "Turing" }
            };

            var mock = new Mock<IRepository<Teacher>>();
            mock.Setup(r => r.List(It.IsAny<QueryOptions<Teacher>>())).Returns(teachers);

            var controller = new TeacherController(mock.Object);

            var result = controller.Index();

            var model = Assert.IsAssignableFrom<IEnumerable<Teacher>>(result.Model);
            Assert.Equal(2, model.Count());
        }

        [Fact]
        public void Add_InvalidModel_DoesNotSave()
        {
            var mock = new Mock<IRepository<Teacher>>();
            var controller = new TeacherController(mock.Object);
            controller.ModelState.AddModelError("LastName", "Required");

            var teacher = new Teacher { FirstName = "Ada" };
            var result = controller.Add(teacher);

            Assert.IsType<ViewResult>(result);
            mock.Verify(r => r.Insert(It.IsAny<Teacher>()), Times.Never);
            mock.Verify(r => r.Save(), Times.Never);
        }

        [Fact]
        public void Add_ValidModel_InsertsAndRedirects()
        {
            var mock = new Mock<IRepository<Teacher>>();
            var controller = new TeacherController(mock.Object);
            var teacher = new Teacher { FirstName = "Ada", LastName = "Lovelace" };

            var result = controller.Add(teacher);

            var redirect = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirect.ActionName);
            mock.Verify(r => r.Insert(teacher), Times.Once);
            mock.Verify(r => r.Save(), Times.Once);
        }
    }
}
